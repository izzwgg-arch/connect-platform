# PBX Blueprint

Read-only PBX blueprint for Cursor.

Includes selected Asterisk/VitalPBX configs, live Asterisk command outputs, and basic system/network info.

Use this for Connect telephony, WebRTC, ARI, AMI, IVR, queues, trunks, tenants, and custom dialplan work.
